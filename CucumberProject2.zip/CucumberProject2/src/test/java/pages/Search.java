package pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import utility.ElementUtil;

public class Search {
	
	 static By searchbox = By.xpath("//input[@name='q']");
	 static final Logger log = Logger.getLogger(Search.class);
	
	public static void enterDataInSearchBox(String value, WebDriver driver) {
		log.info("entered data in search box");
		try {
			System.out.println(value);
			ElementUtil.sendTextToElement(searchbox, value, driver,20);
		} catch (Exception e) {
		
			System.out.print(e);
		}
	}
	public static void clickOnEnterbutton(WebDriver driver) {
		log.info("clicked on search box");
		ElementUtil.clickEnterbutton(searchbox,driver,20);
		
	}
}
