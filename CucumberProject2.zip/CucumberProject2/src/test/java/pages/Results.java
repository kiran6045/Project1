package pages;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import stepdefi.Googlesearchdef;
import utility.ElementUtil;

public class Results {
	
	static final Logger log = Logger.getLogger(Results.class);

	public static void clickOnLinksResultsPages(WebDriver driver) {
		log.info("entered results to collect the links");
		
		
		try {
			
			List<WebElement> alllinks= ElementUtil.clickOnlinks(driver);
			
			for(WebElement link:alllinks)
			{
				link.click();
				driver.navigate().back();  
			}
			
			
		} catch (Exception e) {
		
			System.out.print(e);
		}
	}
}
