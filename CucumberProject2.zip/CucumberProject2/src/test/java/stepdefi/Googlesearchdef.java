package stepdefi;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import baseclass.DriverFactory;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.Results;
import pages.Search;
import utility.ExcelReader;

public class Googlesearchdef{
	WebDriver driver;
	
	static final Logger log = Logger.getLogger(Googlesearchdef.class);
	
	@Given("^Browser is launched & google search page is displayed$")
	public void browser_is_launched_google_search_page_is_displayed() throws Throwable {
		driver=DriverFactory.Launch_browser("Chrome", "https://www.google.com/");

	}
	@When("^Enter the data from \"([^\"]*)\" and (\\d+)$")
	public void enter_the_data_from_and(String Sheetname, int rownumber) throws Throwable {
		System.out.println("enter..................");
		ExcelReader excelread = new ExcelReader();
		
		List<Map<String , String>> testdata=excelread.getData("src\\test\\resources\\TEST_DATA\\Data.xlsx", Sheetname);
	   log.info("Excel data is read");
		String keywordmatch = testdata.get(rownumber).get("Keyword");
		System.out.println("keywordmatch  "+keywordmatch);
		if(keywordmatch.equalsIgnoreCase("search"))
		{
		String searchdata=testdata.get(rownumber).get("Test_data");
		System.out.println("searchdata   "+searchdata);
		Search.enterDataInSearchBox(searchdata,driver);
		log.info("enter data in search box");
		Search.clickOnEnterbutton(driver);

		}
		
		
	}

	@Then("^Click on the links available on the screen$")
	public void click_on_the_links_available_on_the_screen() throws Throwable {
	
		Results.clickOnLinksResultsPages(driver);
		log.info("Clicked on links appeared in the page");
	    
	}
	
	

@Then("^Quit the browser$")
public void quit_the_browser() throws Throwable {
    driver.quit();
	log.info("Quit the browser");
}


}
