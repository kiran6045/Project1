package utility;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



public class ElementUtil   {
	static WebDriver driver;
	WebElement wb1;
	static int counter=0;
	
	
	
	  public ElementUtil(WebDriver driver) {
		this.driver=driver;
	}


	// getting the data from particular element using explicit waits
	public static String getTextFromElement(By location,Duration timeout) {
		String text = null;
		try{
			//set object for wait
			WebDriverWait wait= new WebDriverWait(driver,timeout);
			//wait for location element until given time
		    WebElement element =wait.until(ExpectedConditions.visibilityOfElementLocated(location));
		    //get text value
		    text=element.getText();
		     }
		catch(Exception e){ 
			//print error message if web Element is not found
			System.out.println("Web Element is not found in Page and location of Web Element is :"+location);
			e.printStackTrace();
		}
		return text;
	}
	
	

		public  static void clickEnterbutton(WebDriver driver) {
			
			Actions action = new Actions(driver);
			action.sendKeys(Keys.ENTER);
		
	}
	
	
	//function for click able elements in page using explicit waits
	public  static void clickOnElement(By location,WebDriver driver,int timeout) {
		try {
			WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(timeout));
		   //wait for click elements in web page 
		   WebElement element =wait.until(ExpectedConditions.elementToBeClickable(location));
		   //clicks on the element
		   element.click();
		}
		catch(Exception e) {
			//print error message if web Element is not found
			System.out.println("Web Element is not found in Page and location of Web Element is :"+location);
			e.printStackTrace();
		
		}
		
	}

	
	public WebElement WaitForElement(By locator,int timeout)
	{
		
		try
		{
		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(timeout));
		 wb1=wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
		 return wb1;
		}
		catch (Exception e)
		{
			//System.out.println("no element found");
					return null;
		}
		
		
	}
	
	
	public WebElement WaitForClickable(By locator,int timeout)
	{
		
		try
		{
		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(timeout));
		 wb1=wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
		 return wb1;
		}
		catch (Exception e)
		{
			System.out.println("no element found");
			return null;
		}
		
	}
	
	
	public static void Screenshot() {
		
		String path="src\\test\\resources\\ScreenShot\\";
		String filename=counter+".png";
		
		File f1=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);		
		 File f2= new File(path+filename);
		 try {
			FileUtils.copyFile(f1, f2);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}   
		 counter++;
 
	}


	public static void clickEnterbutton(By location, WebDriver driver, int timeout) {
		try {
			WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(timeout));
		   //wait for click elements in web page 
		   WebElement element =wait.until(ExpectedConditions.elementToBeClickable(location));
		   //clicks on the element
		   element.sendKeys(Keys.ENTER);;
		}
		catch(Exception e) {
			//print error message if web Element is not found
			System.out.println("Web Element is not found in Page and location of Web Element is :"+location);
			e.printStackTrace();
		
		}
		
	}


	public static void sendTextToElement(By location, String value, WebDriver driver, int timeout) {
		try {
			WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(timeout));
		   //wait for click elements in web page 
		   WebElement element =wait.until(ExpectedConditions.presenceOfElementLocated(location));
		   //clicks on the element
		   element.sendKeys(value);;
		}
		catch(Exception e) {
			//print error message if web Element is not found
			System.out.println("Web Element is not found in Page and location of Web Element is :"+location);
			e.printStackTrace();
		
		}
		
	}
	public static List<WebElement> clickOnlinks(WebDriver driver) {
		List<WebElement> allLinks = null;
		try {
			
		    allLinks = driver.findElements(By.partialLinkText("https://www.")); 
			
		}
		catch(Exception e) {
			//print error message if web Element is not found
			System.out.println("Web Element is not found in Page");
		    System.out.println(e);
		
		}
		
		return  allLinks;
	}

}
