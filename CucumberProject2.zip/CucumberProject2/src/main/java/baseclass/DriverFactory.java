package baseclass;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DriverFactory {
	static WebDriver driver;
	WebElement wb1;
	static int counter=0;
	
	static final Logger log = Logger.getLogger(DriverFactory.class);

	public static WebDriver Launch_browser(String browserName,String URL)
	{
		PropertyConfigurator.configure("log4j.properties");
		if (browserName.equalsIgnoreCase("Chrome")) 
		{
            WebDriverManager.chromedriver().setup();
            driver = new ChromeDriver();      
		}
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		driver.get(URL);
		
		log.info(" Chrome Browser is Successfully launched");
		
		return driver;
	}
	
	
	public WebElement WaitForElement(By locator,Duration timeout)
	{
		
		try
		{
		WebDriverWait WDW= new WebDriverWait(driver,timeout);
		 wb1=WDW.until(ExpectedConditions.visibilityOfElementLocated(locator));
		 return wb1;
		}
		catch (Exception e)
		{
			//System.out.println("no element found");
					return null;
		}
		
		
	}
	
	
	public WebElement WaitForClickable(By locator,Duration timeout)
	{
		
		try
		{
		WebDriverWait WDW= new WebDriverWait(driver,timeout);
		 wb1=WDW.until(ExpectedConditions.visibilityOfElementLocated(locator));
		 return wb1;
		}
		catch (Exception e)
		{
			System.out.println("no element found");
			return null;
		}
		
	}
	
	
	public static void Screenshot() {
		
		String path="src\\test\\resources\\ScreenShot\\";
		String filename=counter+".png";
		
		File f1=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);		
		 File f2= new File(path+filename);
		 try {
			FileUtils.copyFile(f1, f2);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}   
		 counter++;
 
	}

}
